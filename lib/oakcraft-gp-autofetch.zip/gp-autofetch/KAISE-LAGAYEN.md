# GP auto-fetch — kaise lagayen

Do tareeke. Dono me wahi code jaata hai.

## A. Patch se (PR wala saaf tareeka)

```bash
git clone https://github.com/Weboakcraft/Oakcraft_Sales_CRM.git
cd Oakcraft_Sales_CRM
git checkout -b gp-autofetch
git am /path/to/0001-gp-autofetch.patch
git push -u origin gp-autofetch
# phir GitHub par "Compare & pull request"
```

## B. Files copy karke

Repo root me daal do:

| File | Naya / badla |
|---|---|
| `gp-bridge.js` | naya |
| `gp-quotation.js` | naya |
| `gp-order.js` | naya |
| `lib/gp-engine.js` | naya (GP calculator ke `assets/engine.js` ki hu-ba-hu copy) |
| `index.html` | badla |
| `quotation-builder.html` | badla |

`android/build.sh` aur `.github/workflows/android-apk.yml` me bhi ek-ek line badli hai
(APK me teeno `gp-*.js` copy hon) — wo patch me hai; files copy wale raste me ye
do badlaav haath se karne padenge, warna Android app me GP panel khali rahega:

* `android/build.sh` — `cp ../index.html …` wali line ke neeche
  `cp ../gp-bridge.js ../gp-quotation.js ../gp-order.js "$OUT/assets/www/"`
* workflow ke `paths:` me `- "gp-*.js"`

## Merge ke baad — ek baar ka setup

1. CRM kholo → **Admin Panel → API Integrations → GP Calculator (cost master)**
2. Sales GP Calculator ke Apps Script ka **`/exec` URL** aur **SHARED_TOKEN** daalo →
   **Save API settings**. (Wahi URL/token jo GP calculator ke `assets/config.js` me
   jaate hain. Jis browser me calculator ka *Connect Sheets* pehle se use hua hai,
   wahan kuch karne ki zarurat nahi.)
3. GP sheet ke **`M_Products`** me har model ka standard armrest / seat mechanism /
   base / wheels bhara ho, aur **`M_Components`** me un parts ke rate. Jo model wahan
   nahi hoga uska GP "adhoora" dikhega — builder me us line par model chun sakte ho
   ya chaaro cost khud bhar sakte ho (agli baar wahi naam khud yaad rakhega).

## Check karne ke liye

Ek nayi quotation kholo → client ka naam type karo (CRM customer list se
auto-fill hoga) → ek product line bharo → neeche **GP · Fayda ya Ghata** panel aur
upar toolbar me rang wali chip aani chahiye. Rate cost se neeche le jao to line laal
ho jaayegi aur chip **GHATA** dikhayegi.
